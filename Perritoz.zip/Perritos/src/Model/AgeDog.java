package Model;

public class AgeDog {
	
}
